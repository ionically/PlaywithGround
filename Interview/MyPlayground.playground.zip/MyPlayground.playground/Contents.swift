import UIKit
//
//var greeting = "Hello, playground"
////block {}
//class Person {
//var name: String // in sabko attributes bolte hain // properties bhi bol sakte hain attributes ko
//    var gender: String // in sabko attributes bolte hain//constant main let aata hain
//    var age: Int // in sabko attributes bolte hain
//    //init jo class unko data types dikhana hi padta hain
//    init(name:String,gender:String,age:Int=8) {
//        self.name = name
//        self.gender = gender
//        self.age = age
//    }
//    //syntax
//    func test(){
//        for i in 0...10 {
//            if i == 8 //check karne==
//            {
//               continue //swift controll statments hain break an continue//syntax hain //8 skip
//        }
//            print(i)
//        }
//    }
//}
////default value
////initialize class
////var p = Person()//ye object diya class ko p
//var p = Person(name: "hannah",gender: "Female") //ye object banaya init (ke initializer) ke wajah se
//print(p.name) //object de raha hain name
//print(p.test())
//func show(name:String){
//    print(name)
//}
////var age = 8 //type inference type bolte hain isko
////closure
////continue statements
////break
class Person {
    var age: Int
    var gender: String
    var name: String
    var add: String
    init(age:Int ,gender:String = "Female",name:String,add:String = "So here Hannah is twenty nine years old and she is a girl or women" ) {
    self.name = name
    self.gender = gender
    self.age = age
    self.add = add
    }
}
var p = Person (age: 29,name: "Hannah")
print(p.name)
print(p.age)
print(p.gender)
print(p.add)

